$(document).ready(function(){
  var print_tab_l = ($(document).width() - 990) / 2+1010
  $(".print_tab").css('left',print_tab_l);

  $(window).resize(function(){
    var print_tab_l = ($(document).width()-990)/2+1010
    $(".print_tab").css('left',print_tab_l);
  });



  $('.print_tab .tabli').click(function(){
    $(this).addClass('on')
    $(this).siblings('.tabli').removeClass('on');
    color = $.trim($('span', this).attr('style').split(':')[1])

    $('.print .header, .print .print_mod .hd').css({backgroundColor: color});
    $('.print .print_price .sale em, .print .print_price .brand_price em').css({color: color});
  });
});
